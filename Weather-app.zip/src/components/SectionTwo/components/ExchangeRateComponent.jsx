const ExchangeRateComponent = () => {
    return (
        <div>
            Exchange Rate Component
        </div>
    )
}

export default ExchangeRateComponent
// https://v2.api.forex/rates/latest.json?from=EUR,USD&to=INR&key=1ca0e1d8-fd30-46c2-b6cd-780e53e01c9c