export const WeatherConstants = {
  SAVE_COORDS: "SAVE_COORDS",
  SAVE_WEATHER: "SAVE_WEATHER",
};
